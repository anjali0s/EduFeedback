import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { GraduationCap, Upload, History, Home } from 'lucide-react';
import { motion } from 'framer-motion';

const Header = () => {
  const location = useLocation();

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/upload', icon: Upload, label: 'Upload' },
    { path: '/history', icon: History, label: 'History' },
  ];

  return (
    <header className="glass-card sticky top-0 z-50">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="bg-gradient-to-br from-indigo-600 to-violet-600 p-2 rounded-xl 
                        group-hover:from-indigo-700 group-hover:to-violet-700 transition-all duration-300
                        shadow-lg shadow-indigo-500/20">
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold gradient-text">
              EduFeedback
            </span>
          </Link>
          
          <div className="flex space-x-8">
            {navItems.map(({ path, icon: Icon, label }) => (
              <Link
                key={path}
                to={path}
                className={`relative group flex items-center space-x-2 px-4 py-2 rounded-xl
                          transition-all duration-300 ${
                            location.pathname === path
                            ? 'text-indigo-600'
                            : 'text-gray-600 hover:text-indigo-600'
                          }`}
              >
                <Icon className="h-5 w-5" />
                <span className="font-medium">{label}</span>
                {location.pathname === path && (
                  <motion.div
                    layoutId="nav-indicator"
                    className="absolute inset-0 bg-indigo-50/50 rounded-xl -z-10"
                    initial={false}
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent 
                            via-indigo-500 to-transparent scale-x-0 group-hover:scale-x-100 
                            transition-transform duration-300"></div>
              </Link>
            ))}
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;